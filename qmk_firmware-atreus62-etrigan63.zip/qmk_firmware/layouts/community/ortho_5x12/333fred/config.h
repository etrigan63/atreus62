#pragma once

#define USE_SERIAL
#define MASTER_LEFT

#undef  TAPPING_TERM
#define TAPPING_TERM 150
